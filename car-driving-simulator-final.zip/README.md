# Car Driving Simulator (Vite + React)

## 🚗 Controls
- Arrow keys to move and rotate the car.

## 🛠 Development
```bash
npm install
npm run dev
```

## 📦 Build for Production
```bash
npm run build
```

## 🌍 Deploy on Vercel
- Framework Preset: `Vite`
- Build Command: `npm run build`
- Output Directory: `dist`